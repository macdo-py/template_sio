prompt --application/pages/page_00000
begin
--   Manifest
--     PAGE: 00000
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>8987418393738822
,p_default_application_id=>1009
,p_default_id_offset=>51114924090547826
,p_default_owner=>'SCHM_LASCAR'
);
wwv_flow_imp_page.create_page(
 p_id=>0
,p_name=>'Global Page'
,p_step_title=>'Global Page'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'D'
,p_page_component_map=>'14'
,p_last_updated_by=>'MCAFIERO_DEV@QABANCOCHILE.ONMICROSOFT.COM'
,p_last_upd_yyyymmddhh24miss=>'20231031105925'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(125052567266880585)
,p_name=>'P0_ACCION'
,p_item_sequence=>10
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(124179489001771481)
,p_name=>'NavMenu Tooltip'
,p_event_sequence=>10
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(124179601123771482)
,p_event_id=>wwv_flow_imp.id(124179489001771481)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'try {',
'',
'//Tooltip for Menu Text ',
'$("#t_TreeNav").treeView("option", "tooltip", { content: function (cb, node) { var ttText;',
'  // Only display the tooltip if the menu is collapsed ...',
'  if ($(".js-navCollapsed ").length > 0) {',
'    ttText = node.label;',
'  }',
'  else {',
'    ttText = "";',
'  }',
'  return ttText;',
'},',
'position: {',
'  my: "left+5 center", at: "right center"',
'},',
' tooltipClass: "add_bg_color",',
'',
'});',
'',
'//This tells the tooltip to show up for the whole node content including the icon. ',
'$("#t_TreeNav").tooltip("option", "items", ".a-TreeView-content");',
'',
'} catch (err) { // Do nothing ...',
'',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(124179637046771483)
,p_name=>'Notificaciones'
,p_event_sequence=>20
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(124179740182771484)
,p_event_id=>wwv_flow_imp.id(124179637046771483)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'PLUGIN_APEX.NOTIFICATION'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{',
'    "refresh": 0,',
'    "mainIcon": "fa-bell",',
'    "mainIconColor": "white",',
'    "mainIconBackgroundColor": "rgba(70,70,70,0.9)",',
'    "mainIconBlinking": false,',
'    "counterBackgroundColor": "rgb(232, 55, 55 )",',
'    "counterFontColor": "white",',
'    "linkTargetBlank": false,',
'    "showAlways": false,',
'    "browserNotifications": {',
'        "enabled": false,',
'        "cutBodyTextAfter": 100,',
'        "link": false',
'    },',
'    "accept": {',
'        "color": "#44e55c",',
'        "icon": "fa-check"',
'    },',
'    "decline": {',
'        "color": "#b73a21",',
'        "icon": "fa-close"',
'    },',
'    "hideOnRefresh": true',
'}'))
,p_attribute_02=>'notification-menu'
,p_attribute_04=>wwv_flow_string.join(wwv_flow_t_varchar2(
' SELECT  NOTE_ICON, ',
'    ''rgb(25,0,93)'' AS NOTE_ICON_COLOR, ',
'    NOTE_HEADER    as NOTE_HEADER,',
'    NOTE_TEXT, ',
'   ',
'  -- APEX_UTIL.PREPARE_URL(''f?p=&APP_ID.:''|| NOTE_PAGE ||'':&APP_SESSION.''|| '':IG::RR,CR:'' || NOTE_PARAMS_NAME || '':'' ||NOTE_PARAMS_VALUE) AS NOTE_LINK, --solo abre la pagina sin marcar leido',
'    ''javascript:',
'    apex.server.process(''''MarcaNotificacion'''',{x01: ''||ID_NOTIF||'' },{',
'      success: function (pData) {',
'        apex.item("AI_RETORNO_MENSAJE").setValue(pData);',
'        apex.region("notification-menu").refresh();',
'        apex.item("P0_ACCION").setValue(pData);',
'        apex.item("P0_ACCION").setValue(''||ID_NOTIF||'' );',
'      },',
'      dataType: "text"',
'    });void(0);',
'    apex.navigation.redirect(''''''||APEX_UTIL.PREPARE_URL(''f?p=&APP_ID.:''|| NOTE_PAGE ||'':&APP_SESSION.''|| '':IG::RR,CR:'' || NOTE_PARAMS_NAME || '':'' ||NOTE_PARAMS_VALUE) || '''''');',
'    '' AS NOTE_LINK,',
'    NOTE_ICON_COLOR AS NOTE_COLOR,',
'    ''javascript:',
'    apex.server.process(''''MarcaNotificacion'''',{x01: ''||ID_NOTIF||'' },{',
'      success: function (pData) {',
'        apex.item("AI_RETORNO_MENSAJE").setValue(pData);',
'        apex.region("notification-menu").refresh();',
'        apex.item("P0_ACCION").setValue(pData);',
'        apex.item("P0_ACCION").setValue(''||ID_NOTIF||'' );',
'      },',
'      dataType: "text"',
'    });void(0);',
'    ''',
'    AS NOTE_ACCEPT,',
'    NULL AS NOTE_DECLINE,',
'    0 AS NO_BROWSER_NOTIFICATION',
'FROM',
'    TBL_NOTIFICACIONES',
'WHERE',
'    NOTE_ESTADO = 0',
'    --AND GC_UTILS.rol_es_valido(NOTE_DESTINO_ROLE, :APP_USER,:APP_ID)=''Y'' ',
' and GC_UTILIDADES_PKG.autorizado(NOTE_DESTINO_ROLE) = ''Y''',
' ',
' order by ID_NOTIF'))
,p_attribute_05=>'N'
,p_attribute_06=>'Y'
,p_attribute_07=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{',
'  "ALLOWED_ATTR": [',
'    "accesskey",',
'    "align",',
'    "alt",',
'    "always",',
'    "autocomplete",',
'    "autoplay",',
'    "border",',
'    "cellpadding",',
'    "cellspacing",',
'    "charset",',
'    "class",',
'    "colspan",',
'    "dir",',
'    "height",',
'    "href",',
'    "id",',
'    "lang",',
'    "name",',
'    "rel",',
'    "required",',
'    "rowspan",',
'    "src",',
'    "style",',
'    "summary",',
'    "tabindex",',
'    "target",',
'    "title",',
'    "type",',
'    "value",',
'    "width"',
'  ],',
'  "ALLOWED_TAGS": [',
'    "a",',
'    "address",',
'    "b",',
'    "blockquote",',
'    "br",',
'    "caption",',
'    "code",',
'    "dd",',
'    "div",',
'    "dl",',
'    "dt",',
'    "em",',
'    "figcaption",',
'    "figure",',
'    "h1",',
'    "h2",',
'    "h3",',
'    "h4",',
'    "h5",',
'    "h6",',
'    "hr",',
'    "i",',
'    "img",',
'    "label",',
'    "li",',
'    "nl",',
'    "ol",',
'    "p",',
'    "pre",',
'    "s",',
'    "span",',
'    "strike",',
'    "strong",',
'    "sub",',
'    "sup",',
'    "table",',
'    "tbody",',
'    "td",',
'    "th",',
'    "thead",',
'    "tr",',
'    "u",',
'    "ul"',
'  ]',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(125611131743043679)
,p_name=>'Success Message auto out'
,p_event_sequence=>30
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(125611261547043680)
,p_event_id=>wwv_flow_imp.id(125611131743043679)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.message.setThemeHooks({',
'  beforeShow: function(pMsgType, pElement$){',
'    if (pMsgType==apex.message.TYPE.SUCCESS){ ',
'   setTimeout(function() {',
'        $(''.t-Body-alert .t-Alert'').fadeOut(''slow'');',
'      }, 3000);',
'    }   ',
'  }',
'});'))
);
wwv_flow_imp.component_end;
end;
/

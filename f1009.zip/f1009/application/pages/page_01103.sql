prompt --application/pages/page_01103
begin
--   Manifest
--     PAGE: 01103
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>8987418393738822
,p_default_application_id=>1009
,p_default_id_offset=>51114924090547826
,p_default_owner=>'SCHM_LASCAR'
);
wwv_flow_imp_page.create_page(
 p_id=>1103
,p_name=>'Borra Parametro'
,p_alias=>'BORRA-PARAMETRO'
,p_page_mode=>'MODAL'
,p_step_title=>'Borra Parametro'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(129861685915268482)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'16'
,p_last_updated_by=>'MCAFIERO_DEV@QABANCOCHILE.ONMICROSOFT.COM'
,p_last_upd_yyyymmddhh24miss=>'20231030164915'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(105709919612917390)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--warning:t-Alert--removeHeading js-removeLandmark'
,p_plug_template=>wwv_flow_imp.id(129871884567268487)
,p_plug_display_sequence=>40
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Parametro: &P1103_PARAM. <br>',
'Ambiente: &P1103_AMB.'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(53557454196579677)
,p_button_sequence=>50
,p_button_name=>'CANCELAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(130015949320268566)
,p_button_image_alt=>'Cancelar'
,p_grid_new_row=>'Y'
,p_grid_column=>8
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(53557882121579677)
,p_button_sequence=>60
,p_button_name=>'ACEPTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(130016029686268567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Aceptar'
,p_icon_css_classes=>'fa-window-x'
,p_grid_new_row=>'N'
,p_grid_column=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(105710632876917384)
,p_name=>'P1103_PARAM'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(105710697511917385)
,p_name=>'P1103_AMB'
,p_item_sequence=>30
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(53558954410579678)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'DELETE PARAM'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'delete from TBL_PARAMETROS',
'where PARAMETRO_NOMBRE = :P1103_PARAM and AMBIENTE = :P1103_AMB;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(53557882121579677)
,p_internal_uid=>53558954410579678
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(53559389194579679)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'CLOSE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>53559389194579679
);
wwv_flow_imp.component_end;
end;
/

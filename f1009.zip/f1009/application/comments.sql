prompt --application/comments
begin
--   Manifest
--     APPLICATION COMMENTS: 1009
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>8987418393738822
,p_default_application_id=>1009
,p_default_id_offset=>51114924090547826
,p_default_owner=>'SCHM_LASCAR'
);
wwv_flow_imp_shared.create_app_comments(
 p_id=>wwv_flow_imp.id(53579451620673736)
,p_pages=>'24'
,p_app_comment=>'Cambiar nombre a 1024'
,p_updated_on=>'2023.10.30.17:04:56'
,p_updated_by=>'MCAFIERO_DEV@QABANCOCHILE.ONMICROSOFT.COM'
,p_created_on=>'2023.10.30.17:04:56'
,p_created_by=>'MCAFIERO_DEV@QABANCOCHILE.ONMICROSOFT.COM'
);
wwv_flow_imp.component_end;
end;
/

prompt --application/deployment/buildoptions
begin
--   Manifest
--     INSTALL BUILD OPTIONS: 1009
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>8987418393738822
,p_default_application_id=>1009
,p_default_id_offset=>51114924090547826
,p_default_owner=>'SCHM_LASCAR'
);
wwv_flow_imp_shared.create_install_build_option(
 p_id=>wwv_flow_imp.id(55425949801329251)
,p_install_id=>wwv_flow_imp.id(127165865004447021)
,p_build_opt_id=>wwv_flow_imp.id(101835408175650719)
);
wwv_flow_imp_shared.create_install_build_option(
 p_id=>wwv_flow_imp.id(55426023578329251)
,p_install_id=>wwv_flow_imp.id(127165865004447021)
,p_build_opt_id=>wwv_flow_imp.id(129839711494268453)
);
wwv_flow_imp.component_end;
end;
/

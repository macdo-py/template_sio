prompt --application/shared_components/security/authentications/azure_ad
begin
--   Manifest
--     AUTHENTICATION: Azure AD
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>8987418393738822
,p_default_application_id=>1009
,p_default_id_offset=>51114924090547826
,p_default_owner=>'SCHM_LASCAR'
);
wwv_flow_imp_shared.create_authentication(
 p_id=>wwv_flow_imp.id(98848555836676984)
,p_name=>'Azure AD'
,p_scheme_type=>'NATIVE_SOCIAL'
,p_attribute_01=>wwv_flow_imp.id(47730606689702561)
,p_attribute_02=>'OAUTH2'
,p_attribute_04=>'https://login.microsoftonline.com/11841e97-4eec-4c4f-9a94-dffb32729af6/oauth2/v2.0/authorize'
,p_attribute_05=>'https://login.microsoftonline.com/11841e97-4eec-4c4f-9a94-dffb32729af6/oauth2/v2.0/token'
,p_attribute_06=>'https://graph.microsoft.com/v1.0/me'
,p_attribute_07=>'openid'
,p_attribute_09=>'userPrincipalName'
,p_attribute_10=>'userPrincipalName, displayName'
,p_attribute_11=>'N'
,p_attribute_12=>'BASIC_AND_CLID'
,p_attribute_13=>'Y'
,p_attribute_14=>'USERPRINCIPALNAME, DISPLAYNAME'
,p_plsql_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PROCEDURE after_login',
'AS',
'	l_roles apex_t_varchar2;',
'	l_id_token apex_jwt.t_token;',
'    l_clob CLOB;',
'    e_no_groups exception;',
'    l_access_token bLOB;',
'    l_response cLOB;',
'    j apex_json.t_values; ',
'',
'BEGIN',
'    apex_debug.enable(p_level => apex_debug.c_log_level_info);',
'    apex_debug.message(''Extrae Token'');',
'    --Extrae y decodifica el ID TOKEN desde la respuesta de Azure AD',
'    apex_debug.message(''Token:''|| apex_json.get_varchar2(p_path => ''id_token''));',
'    l_id_token := apex_jwt.decode (p_value => apex_json.get_varchar2(p_path => ''id_token''));',
'    apex_debug.message(''Parse Token'');',
'    --Parsea el contenido del token',
'    apex_json.parse(l_id_token.payload);',
'    apex_debug.message(p_message => ''Token:''||l_id_token.payload);',
'    ',
'    ',
'',
'    --Rescata el arreglo "roles" que contiene los roles asignados al usuario validado',
'    l_roles := apex_json.get_t_varchar2 (p_path => ''roles'');',
'    apex_debug.message(''Extrae Grupos'');',
'    for i in 1 .. l_roles.count loop',
'        :G_ROLES := :G_ROLES || '','' || REPLACE(l_roles(i),''OCI_'',''''); --Asigna los roles a un Application Item',
'        l_roles(i) := REPLACE(l_roles(i),''OCI_'','''');',
'    end loop;',
'    :G_ROLES := ltrim(:G_ROLES,'','');',
'    apex_debug.message(''G_ROLES:'' || :G_ROLES);',
unistr('    --Agrega los roles como grupos din\00E1micos'),
'    apex_authorization.enable_dynamic_groups (p_group_names => l_roles);',
'    --apex_debug.message(''APP_USER:'' || :APP_USER);',
'    --apex_debug.message(''RETORNA_USERNAME:'' || gc_utilidades_pkg.retorna_username(:APP_USER));',
'    ',
'    --Si el usuario no tiene roles genera logout',
'        /*',
'        IF :G_ROLES IS NULL THEN',
'            RAISE e_no_groups;',
'        END IF; ',
'        */',
'    apex_custom_auth.set_user(gc_utilidades_pkg.retorna_username(:APP_USER)); --le saca el dev o qa y @....',
'',
'',
'-- Make the REST request using apex_web_service.make_rest_request',
'  l_access_token := apex_web_service.make_rest_request_b(',
'    p_url => ''https://graph.microsoft.com/v1.0/me/photo/$value'', --',
'    p_http_method => ''GET''',
'   ',
'  );',
'  ',
'l_response := apex_web_service.make_rest_request(',
'    p_url => ''https://graph.microsoft.com/v1.0/me/photo'', --',
'    p_http_method => ''GET''',
'  );',
'',
'apex_debug.message(''Photo Metadata: '' || l_response);',
'apex_json.parse(j, l_response);',
'apex_debug.message(''Get Count:'' || apex_json.get_count(p_path=>''error'',p_values=>j));',
'',
'',
'if apex_json.get_count(p_path=>''error'',p_values=>j) > 1 then',
'    select FILE_CONTENT',
'    INTO l_access_token',
'    from apex_workspace_static_files where FILE_NAME=''nobody.jpeg'';',
'    ',
'    apex_collection.create_or_truncate_collection(''USER_PIC'');',
'   apex_collection.add_member(',
'    p_collection_name => ''USER_PIC'',',
'    p_c001 => l_response --comment_text',
'    ,p_blob001 =>l_access_token',
'    ,p_n001 =>  nvl(sys.dbms_lob.getlength(l_access_token),0)',
'    );',
'else',
'    apex_collection.create_or_truncate_collection(''USER_PIC'');',
'    apex_collection.add_member(',
'    p_collection_name => ''USER_PIC'',',
'    p_c001 => l_response --comment_text',
'    ,p_blob001 =>l_access_token',
'    ,p_n001 =>  nvl(sys.dbms_lob.getlength(l_access_token),0)',
'    );',
'end if;',
'',
'EXCEPTION',
'    WHEN e_no_groups THEN',
'        apex_debug.message(''Sin grupos asignados'');',
'        apex_string.push(l_roles, ''DUMMY'');',
'        apex_authorization.enable_dynamic_groups (p_group_names => l_roles);',
'    WHEN OTHERS THEN',
'        apex_debug.message(''Exception: ''||SQLERRM||'' - ''||DBMS_UTILITY.format_error_backtrace);',
'        apex_string.push(l_roles, ''DUMMY'');',
'        apex_authorization.enable_dynamic_groups (p_group_names => l_roles);  ',
'END;'))
,p_invalid_session_type=>'LOGIN'
,p_post_auth_process=>'after_login'
,p_use_secure_cookie_yn=>'N'
,p_ras_mode=>0
);
wwv_flow_imp.component_end;
end;
/

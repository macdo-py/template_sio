prompt --application/shared_components/security/authorizations/lascar
begin
--   Manifest
--     SECURITY SCHEME: LASCAR
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>8987418393738822
,p_default_application_id=>1009
,p_default_id_offset=>51114924090547826
,p_default_owner=>'SCHM_LASCAR'
);
wwv_flow_imp_shared.create_security_scheme(
 p_id=>wwv_flow_imp.id(99011767686607442)
,p_name=>'LASCAR'
,p_scheme_type=>'NATIVE_IS_IN_GROUP'
,p_attribute_01=>'DEV_APEX_LASCAR_ADMIN,DEV_APEX_LASCAR_CONSULTA,r_evaluador,r_operador'
,p_attribute_02=>'W'
,p_error_message=>unistr('No est\00E1 autorizado para acceder a esta aplicaci\00F3n. Contacte al administrador de sistema.')
,p_caching=>'BY_USER_BY_SESSION'
);
wwv_flow_imp.component_end;
end;
/

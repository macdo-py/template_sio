prompt --application/shared_components/logic/application_processes/foto_perfil
begin
--   Manifest
--     APPLICATION PROCESS: FOTO_PERFIL
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>8987418393738822
,p_default_application_id=>1009
,p_default_id_offset=>51114924090547826
,p_default_owner=>'SCHM_LASCAR'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(99022595532891788)
,p_process_sequence=>1
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'FOTO_PERFIL'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--#WORKSPACE_FILES#nobody.jpeg',
'Begin',
'',
'for c1 in ',
'    --(select foto pic, sys.dbms_lob.getlength(foto) pic_size from foto_usuarios WHERE lower(USERPRINCIPALNAME) = lower(:APP_USER)) loop',
'    (select blob001 pic, sys.dbms_lob.getlength(blob001) pic_size from apex_collections WHERE collection_name = ''USER_PIC'') loop',
'    sys.htp.init;',
'    sys.owa_util.mime_header(''image/jpeg'', false);',
'    sys.htp.p(''Content-length: '' || c1.pic_size);',
'    sys.htp.p(''Content-Disposition: inline; filename="'' ||  DBMS_RANDOM.VALUE(1, 100) || ''_pic.jpeg"'');',
'    sys.htp.p(''Cache-Control: max-age=3600'');',
'    sys.owa_util.http_header_close;',
'    sys.wpg_docload.download_file(c1.pic);',
'    apex_application.stop_apex_engine;',
'    end loop;',
'',
'',
'',
'exception when others then',
'    apex_application.stop_apex_engine;',
'   ',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_security_scheme=>'MUST_NOT_BE_PUBLIC_USER'
);
wwv_flow_imp.component_end;
end;
/

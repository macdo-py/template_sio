prompt --application/shared_components/logic/application_processes/crea_imagen
begin
--   Manifest
--     APPLICATION PROCESS: CREA_IMAGEN
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>8987418393738822
,p_default_application_id=>1009
,p_default_id_offset=>51114924090547826
,p_default_owner=>'SCHM_LASCAR'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(53249463485283263)
,p_process_sequence=>1
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'CREA_IMAGEN'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    for c1 in (select *',
'                 FROM   tbl_ayuda_imagenes I',
'  WHERE  I.id = :AI_IMG_ID) loop',
'        --',
'        sys.htp.init;',
'        sys.owa_util.mime_header( c1.mime_type, FALSE );',
'        sys.htp.p(''Content-length: '' || sys.dbms_lob.getlength( c1."IMAGE"));',
'        sys.htp.p(''Content-Disposition: inline; filename="'' || c1.file_name || ''"'' );',
'        sys.htp.p(''Cache-Control: max-age=3600'');  -- tell the browser to cache for one hour, adjust as necessary',
'        sys.owa_util.http_header_close;',
'        sys.wpg_docload.download_file( c1.IMAGE );',
'     ',
'        apex_application.stop_apex_engine;',
'    end loop;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_security_scheme=>'MUST_NOT_BE_PUBLIC_USER'
);
wwv_flow_imp.component_end;
end;
/

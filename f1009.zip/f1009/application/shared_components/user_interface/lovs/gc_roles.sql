prompt --application/shared_components/user_interface/lovs/gc_roles
begin
--   Manifest
--     GC_ROLES
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>8987418393738822
,p_default_application_id=>1009
,p_default_id_offset=>51114924090547826
,p_default_owner=>'SCHM_LASCAR'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(126806153338328941)
,p_lov_name=>'GC_ROLES'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select role_name rol, role_id rol_id',
'from APEX_APPL_ACL_ROLES where application_id = :APP_ID ',
'union select ''Todos'', -1 from dual'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_return_column_name=>'ROL'
,p_display_column_name=>'ROL'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'ROL'
,p_default_sort_direction=>'ASC'
);
wwv_flow_imp.component_end;
end;
/

prompt --application/shared_components/user_interface/lovs/gc_accion_carga_lov
begin
--   Manifest
--     GC_ACCION_CARGA_LOV
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>8987418393738822
,p_default_application_id=>1009
,p_default_id_offset=>51114924090547826
,p_default_owner=>'SCHM_LASCAR'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(124569272971137610)
,p_lov_name=>'GC_ACCION_CARGA_LOV'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_query_table=>'GC_ACCION_CARGA'
,p_return_column_name=>'ID'
,p_display_column_name=>'ACCION_CARGA'
,p_default_sort_column_name=>'ACCION_CARGA'
,p_default_sort_direction=>'ASC'
);
wwv_flow_imp.component_end;
end;
/

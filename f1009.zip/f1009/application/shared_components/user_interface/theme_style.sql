prompt --application/shared_components/user_interface/theme_style
begin
--   Manifest
--     THEME STYLE: 1009
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>8987418393738822
,p_default_application_id=>1009
,p_default_id_offset=>51114924090547826
,p_default_owner=>'SCHM_LASCAR'
);
wwv_flow_imp_shared.create_theme_style(
 p_id=>wwv_flow_imp.id(121532608918388474)
,p_theme_id=>42
,p_name=>'Redwood Light'
,p_css_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#APEX_FILES#libraries/oracle-fonts/oraclesans-apex#MIN#.css?v=#APEX_VERSION#',
'#THEME_FILES#css/Redwood#MIN#.css?v=#APEX_VERSION#'))
,p_is_current=>false
,p_is_public=>true
,p_is_accessible=>false
,p_theme_roller_input_file_urls=>'#THEME_FILES#less/theme/Redwood-Theme.less'
,p_theme_roller_output_file_url=>'#THEME_FILES#css/Redwood-Theme#MIN#.css?v=#APEX_VERSION#'
,p_theme_roller_read_only=>true
,p_reference_id=>2596426436825065489
);
wwv_flow_imp_shared.create_theme_style(
 p_id=>wwv_flow_imp.id(121532975538388475)
,p_theme_id=>42
,p_name=>'Vita'
,p_is_current=>false
,p_is_public=>true
,p_is_accessible=>true
,p_theme_roller_input_file_urls=>'#THEME_FILES#less/theme/Vita.less'
,p_theme_roller_output_file_url=>'#THEME_FILES#css/Vita#MIN#.css?v=#APEX_VERSION#'
,p_theme_roller_read_only=>true
,p_reference_id=>2719875314571594493
);
wwv_flow_imp_shared.create_theme_style(
 p_id=>wwv_flow_imp.id(121533396177388475)
,p_theme_id=>42
,p_name=>'Vita - Dark'
,p_is_current=>false
,p_is_public=>true
,p_is_accessible=>false
,p_theme_roller_input_file_urls=>'#THEME_FILES#less/theme/Vita-Dark.less'
,p_theme_roller_output_file_url=>'#THEME_FILES#css/Vita-Dark#MIN#.css?v=#APEX_VERSION#'
,p_theme_roller_read_only=>true
,p_reference_id=>3543348412015319650
);
wwv_flow_imp_shared.create_theme_style(
 p_id=>wwv_flow_imp.id(121533801566388475)
,p_theme_id=>42
,p_name=>'Vita - Red'
,p_is_current=>false
,p_is_public=>true
,p_is_accessible=>false
,p_theme_roller_input_file_urls=>'#THEME_FILES#less/theme/Vita-Red.less'
,p_theme_roller_output_file_url=>'#THEME_FILES#css/Vita-Red#MIN#.css?v=#APEX_VERSION#'
,p_theme_roller_read_only=>true
,p_reference_id=>1938457712423918173
);
wwv_flow_imp_shared.create_theme_style(
 p_id=>wwv_flow_imp.id(121534176980388475)
,p_theme_id=>42
,p_name=>'Vita - Slate'
,p_is_current=>false
,p_is_public=>true
,p_is_accessible=>false
,p_theme_roller_input_file_urls=>'#THEME_FILES#less/theme/Vita-Slate.less'
,p_theme_roller_output_file_url=>'#THEME_FILES#css/Vita-Slate#MIN#.css?v=#APEX_VERSION#'
,p_theme_roller_read_only=>true
,p_reference_id=>3291983347983194966
);
wwv_flow_imp_shared.create_theme_style(
 p_id=>wwv_flow_imp.id(131467902669870370)
,p_theme_id=>42
,p_name=>'Vita (copy_1)'
,p_is_current=>true
,p_is_public=>true
,p_is_accessible=>true
,p_theme_roller_input_file_urls=>'#THEME_FILES#less/theme/Vita.less'
,p_theme_roller_config=>'{"classes":[],"vars":{"@g_Nav-Icon":"#ffffff","@g_Nav-Icon-Active":"#ffffff","@g_Header-BG":"#00275c","@g_Header-FG":"#ffffff","@g_Nav-BG":"#00275c","@g_Nav-FG":"#ffffff","@g_Nav-Active-BG":"#021c4d","@g_Nav-Active-FG":"#ffffff","@g_Nav-Accent-BG":"#'
||'2374ab","@g_Nav-Accent-FG":"#ffffff","@g_Nav-Badge-BG":"#00275c","@g_Nav-Badge-FG":"#ffffff","@g_Primary-BG":"#acd3ee","@g_Primary-FG":"#050f17","@l_Button-Hot-BG":"#00275c","@l_Button-Hot-Text":"#ffffff"},"customCSS":"","useCustomLess":"Y"}'
,p_theme_roller_output_file_url=>'#THEME_DB_FILES#80352978579322544.css'
,p_theme_roller_read_only=>false
);
wwv_flow_imp_shared.create_theme_style(
 p_id=>wwv_flow_imp.id(137679465903086920)
,p_theme_id=>113
,p_name=>'BCH'
,p_is_current=>false
,p_is_public=>true
,p_is_accessible=>true
,p_theme_roller_input_file_urls=>'#THEME_IMAGES#less/theme/Vita.less'
,p_theme_roller_config=>'{"classes":[],"vars":{"@g_Nav-BG":"#021c4d","@g_Nav-FG":"#ffffff","@g_Nav-Badge-BG":"#021c4d","@g_Nav-Badge-FG":"#ffffff","@g_Nav-Active-BG":"#021c4d","@g_Nav-Active-FG":"#ffffff","@g_Header-BG":"#021c4d","@g_Header-FG":"#ffffff","@l_Button-Hot-BG":"'
||'#021c4d","@l_Button-Hot-Text":"#ffffff","@g_Nav-Accent-BG":"#2374ab","@g_Nav-Accent-FG":"#ffffff","@g_NavBarMenu-Active-BG":"#2374ab","@g_NavBarMenu-Active-FG":"#ffffff","@g_Accent-BG":"#2374ab"},"customCSS":"","useCustomLess":"N"}'
,p_theme_roller_output_file_url=>'#THEME_DB_FILES#8469163805272920.css'
,p_theme_roller_read_only=>false
,p_reference_id=>8739608620443150
);
wwv_flow_imp_shared.create_theme_style(
 p_id=>wwv_flow_imp.id(137679627286086921)
,p_theme_id=>113
,p_name=>'BCH_v1'
,p_is_current=>true
,p_is_public=>true
,p_is_accessible=>true
,p_theme_roller_input_file_urls=>'#THEME_IMAGES#less/theme/Vita.less'
,p_theme_roller_config=>'{"classes":[],"vars":{"@g_Nav-BG":"#021c4d","@g_Nav-FG":"#ffffff","@g_Nav-Badge-BG":"#021c4d","@g_Nav-Badge-FG":"#ffffff","@g_Nav-Active-BG":"#021c4d","@g_Nav-Active-FG":"#ffffff","@g_Header-BG":"#021c4d","@g_Header-FG":"#ffffff","@l_Button-Hot-BG":"'
||'#021c4d","@l_Button-Hot-Text":"#ffffff","@g_Nav-Accent-BG":"#2374ab","@g_Nav-Accent-FG":"#ffffff","@g_NavBarMenu-Active-BG":"#2374ab","@g_NavBarMenu-Active-FG":"#ffffff","@g_Accent-BG":"#2374ab"},"customCSS":"    .ui-tooltip.add_bg_color {     color:'
||' #fff;     background: hsl(219, 95%, 15%); }","useCustomLess":"Y"}'
,p_theme_roller_output_file_url=>'#THEME_DB_FILES#9905086468751422.css'
,p_theme_roller_read_only=>false
,p_reference_id=>9905086468751422
);
wwv_flow_imp.component_end;
end;
/

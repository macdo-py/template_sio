prompt --workspace/credentials/azuread_lascar_dev
begin
--   Manifest
--     CREDENTIAL: AzureAD LASCAR_dev
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>8987418393738822
,p_default_application_id=>1009
,p_default_id_offset=>51114924090547826
,p_default_owner=>'SCHM_LASCAR'
);
wwv_imp_workspace.create_credential(
 p_id=>wwv_flow_imp.id(47730606689702561)
,p_name=>'AzureAD LASCAR_dev'
,p_static_id=>'AzureAD_LASCAR_dev'
,p_authentication_type=>'OAUTH2_CLIENT_CREDENTIALS'
,p_scope=>'User.Read'
,p_prompt_on_install=>true
);
wwv_flow_imp.component_end;
end;
/

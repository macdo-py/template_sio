prompt --application/shared_components/user_interface/lovs/gc_accion_carga
begin
--   Manifest
--     GC_ACCION_CARGA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>8987418393738822
,p_default_application_id=>109
,p_default_id_offset=>55542300333660635
,p_default_owner=>'SCHM_LASCAR'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(179786097488842561)
,p_lov_name=>'GC_ACCION_CARGA'
,p_lov_query=>'.'||wwv_flow_imp.id(179786097488842561)||'.'
,p_location=>'STATIC'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(179786366223842566)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>unistr('Inserci\00F3n')
,p_lov_return_value=>'1'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(179786762048842567)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>unistr('Modificaci\00F3n')
,p_lov_return_value=>'2'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(179787180054842567)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>'Reemplazo'
,p_lov_return_value=>'3'
);
wwv_flow_imp.component_end;
end;
/

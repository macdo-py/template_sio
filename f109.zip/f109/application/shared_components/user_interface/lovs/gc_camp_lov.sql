prompt --application/shared_components/user_interface/lovs/gc_camp_lov
begin
--   Manifest
--     GC_CAMP_LOV
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>8987418393738822
,p_default_application_id=>109
,p_default_id_offset=>55542300333660635
,p_default_owner=>'SCHM_LASCAR'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(179768998353278232)
,p_lov_name=>'GC_CAMP_LOV'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id_campana, campana, id_campana as ID    ',
'from GC_CAMPANAS'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_return_column_name=>'ID_CAMPANA'
,p_display_column_name=>'CAMPANA'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'ID_CAMPANA'
,p_default_sort_direction=>'ASC'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(179772737845418445)
,p_query_column_name=>'CAMPANA'
,p_heading=>unistr('Campa\00F1a')
,p_display_sequence=>10
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(179773169390418445)
,p_query_column_name=>'ID_CAMPANA'
,p_heading=>unistr('ID Campa\00F1a')
,p_display_sequence=>10
,p_data_type=>'NUMBER'
,p_is_visible=>'N'
,p_is_searchable=>'N'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(179774540873424910)
,p_query_column_name=>'ID'
,p_heading=>'Id'
,p_display_sequence=>10
,p_data_type=>'NUMBER'
);
wwv_flow_imp.component_end;
end;
/

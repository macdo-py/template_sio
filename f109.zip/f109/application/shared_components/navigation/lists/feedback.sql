prompt --application/shared_components/navigation/lists/feedback
begin
--   Manifest
--     LIST: Feedback
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>8987418393738822
,p_default_application_id=>109
,p_default_id_offset=>55542300333660635
,p_default_owner=>'SCHM_LASCAR'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(106699512046212647)
,p_name=>'Feedback'
,p_list_status=>'PUBLIC'
,p_required_patch=>wwv_flow_imp.id(106659838395212588)
);
wwv_flow_imp.component_end;
end;
/

prompt --application/shared_components/navigation/breadcrumbentry
begin
--   Manifest
--     BREADCRUMB ENTRY: 
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>8987418393738822
,p_default_application_id=>109
,p_default_id_offset=>55542300333660635
,p_default_owner=>'SCHM_LASCAR'
);
null;
wwv_flow_imp.component_end;
end;
/

prompt --application/shared_components/security/authorizations/sup_priv
begin
--   Manifest
--     SECURITY SCHEME: Sup Priv
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>8987418393738822
,p_default_application_id=>109
,p_default_id_offset=>55542300333660635
,p_default_owner=>'SCHM_LASCAR'
);
wwv_flow_imp_shared.create_security_scheme(
 p_id=>wwv_flow_imp.id(179943692602147666)
,p_name=>'Sup Priv'
,p_scheme_type=>'NATIVE_IS_IN_GROUP'
,p_attribute_01=>'DEV_APEX_LASCAR_SUPERVISOR'
,p_attribute_02=>'W'
,p_error_message=>'Insufficient privileges, user is not an Evaluador'
,p_caching=>'BY_USER_BY_SESSION'
);
wwv_flow_imp.component_end;
end;
/

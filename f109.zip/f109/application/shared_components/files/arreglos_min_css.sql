prompt --application/shared_components/files/arreglos_min_css
begin
--   Manifest
--     APP STATIC FILES: 109
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>8987418393738822
,p_default_application_id=>109
,p_default_id_offset=>55542300333660635
,p_default_owner=>'SCHM_LASCAR'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '2E75692D746F6F6C7469702E6164645F62675F636F6C6F727B636F6C6F723A236666663B6261636B67726F756E643A233032316234627D2E742D427574746F6E2D2D6E6176426172202E742D427574746F6E2D62616467657B6261636B67726F756E642D';
wwv_flow_imp.g_varchar2_table(2) := '636F6C6F723A696E697469616C7D2E696D677B70616464696E673A307D3A726F6F747B2D2D75742D6865616465722D6865696768743A3372656D7D2E742D427574746F6E2D2D6E61764261727B6865696768743A3238707821696D706F7274616E747D';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(157484674617795897)
,p_file_name=>'arreglos.min.css'
,p_mime_type=>'text/css'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/

prompt --application/shared_components/files/arreglos_css
begin
--   Manifest
--     APP STATIC FILES: 109
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>8987418393738822
,p_default_application_id=>109
,p_default_id_offset=>55542300333660635
,p_default_owner=>'SCHM_LASCAR'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '2E75692D746F6F6C7469702E6164645F62675F636F6C6F72207B2020202020636F6C6F723A20236666663B20202020206261636B67726F756E643A2068736C283231392C203935252C20313525293B207D0A2E742D427574746F6E2D2D6E617642617220';
wwv_flow_imp.g_varchar2_table(2) := '2E742D427574746F6E2D6261646765207B0A20202020202020206261636B67726F756E642D636F6C6F723A20696E697469616C3B0A7D0A2E696D67207B0A202070616464696E673A20303B0A7D0A3A726F6F74207B0A202020202D2D75742D6865616465';
wwv_flow_imp.g_varchar2_table(3) := '722D6865696768743A203372656D3B0A7D0A0A2E742D427574746F6E2D2D6E61764261720A7B6865696768743A20323870782021696D706F7274616E743B0A0A7D0A';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(157476324722676044)
,p_file_name=>'arreglos.css'
,p_mime_type=>'text/css'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/

prompt --application/shared_components/logic/application_processes/marcanotificacion
begin
--   Manifest
--     APPLICATION PROCESS: MarcaNotificacion
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>8987418393738822
,p_default_application_id=>109
,p_default_id_offset=>55542300333660635
,p_default_owner=>'SCHM_LASCAR'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(180907391313251869)
,p_process_sequence=>1
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'MarcaNotificacion'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'begin',
'    update TBL_NOTIFICACIONES',
'    SET NOTE_ESTADO = 1',
'    --WHERE id_notif = :ID_NOTIF;',
'    WHERE id_notif = apex_application.g_x01;',
'',
' --insert into log (ver) values(1);   ',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_security_scheme=>'MUST_NOT_BE_PUBLIC_USER'
);
wwv_flow_imp.component_end;
end;
/

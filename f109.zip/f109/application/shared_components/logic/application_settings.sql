prompt --application/shared_components/logic/application_settings
begin
--   Manifest
--     APPLICATION SETTINGS: 109
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>8987418393738822
,p_default_application_id=>109
,p_default_id_offset=>55542300333660635
,p_default_owner=>'SCHM_LASCAR'
);
wwv_flow_imp_shared.create_app_setting(
 p_id=>wwv_flow_imp.id(106660111250212589)
,p_name=>'FEEDBACK_ATTACHMENTS_YN'
,p_value=>'Y'
,p_is_required=>'N'
,p_valid_values=>'Y, N'
,p_on_upgrade_keep_value=>true
,p_required_patch=>wwv_flow_imp.id(106659838395212588)
);
wwv_flow_imp.component_end;
end;
/

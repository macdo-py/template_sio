prompt --application/pages/page_01026
begin
--   Manifest
--     PAGE: 01026
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>8987418393738822
,p_default_application_id=>109
,p_default_id_offset=>55542300333660635
,p_default_owner=>'SCHM_LASCAR'
);
wwv_flow_imp_page.create_page(
 p_id=>1026
,p_name=>'Ayuda Notificaciones'
,p_alias=>'AYUDA-NOTIFICACIONES'
,p_step_title=>'Ayuda Notificaciones'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  .hljs-copy {',
'         float: right;',
'         cursor: pointer;',
'        background-color: #0769C7;',
'  color: white;',
'  padding: 5px;',
'  border-radius: 5px;',
'  /*margin: 10px;*/',
'  ',
'  border: none;',
'  /*background: transparent;*/',
'     }',
'',
'.hljs-copy:hover {',
'  background-color: #fff;',
'  color: #0769C7;',
'}',
'',
'.code_width{',
'  width: 50%;',
'  overflow-x: auto;',
'  padding: 10px;',
'  word-wrap: break-word;',
'',
'}',
'',
'',
'',
''))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'03'
,p_last_updated_by=>'MCAFIERO_DEV@QABANCOCHILE.ONMICROSOFT.COM'
,p_last_upd_yyyymmddhh24miss=>'20231109182820'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(269886545237260090)
,p_name=>'New'
,p_template=>wwv_flow_imp.id(185485366179929158)
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select file_name, ',
'''<img src="f?p=&APP_ID.:24:&SESSION.:APPLICATION_PROCESS=CREA_IMAGEN:::AI_IMG_ID:'' || ID || ''">'' as  img',
'FROM tbl_ayuda_imagenes',
'where id_ayuda = :P1026_ID_AYUDA'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(185523214946929176)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_required_patch=>wwv_flow_imp.id(185382011827929088)
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(56527844112347981)
,p_query_column_id=>1
,p_column_alias=>'FILE_NAME'
,p_column_display_sequence=>10
,p_column_heading=>'File Name'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(56528244757347982)
,p_query_column_id=>2
,p_column_alias=>'IMG'
,p_column_display_sequence=>20
,p_column_heading=>'Img'
,p_use_as_row_header=>'N'
,p_column_format=>'PCT_GRAPH:::'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(269889324111260118)
,p_plug_name=>'Titulo'
,p_region_name=>'titulo'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_region_attributes=>'style="border: none; border-bottom: none; border-block-end-style: none;"'
,p_plug_template=>wwv_flow_imp.id(185485366179929158)
,p_plug_display_sequence=>40
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(269893177482260113)
,p_name=>'P1026_AYUDA'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(269889324111260118)
,p_prompt=>'&nbsp;'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'l_html clob;',
'l_image_data BLOB;',
'l_file_name varchar(500);',
'l_size number;',
'l_id number;',
'l_url varchar2(300);',
'BEGIN',
'  SELECT p.parrafo',
'	INTO l_html',
'	FROM tbl_ayuda p',
'   WHERE p.id = :P1026_ID_AYUDA;',
'',
'  FOR i IN (SELECT  ID, "IMAGE" , "FILE_NAME", blob_size',
'  			FROM tbl_ayuda_imagenes',
'			 WHERE id_ayuda = :P1026_ID_AYUDA',
'			 ORDER BY id)',
'  LOOP',
'      l_id:=i.id;',
'    l_image_data:= i."IMAGE";',
'    l_file_name:= i."FILE_NAME";',
'    l_size := i.blob_size;',
'',
'    l_url := ''f?p=&APP_ID.:24:&SESSION.:APPLICATION_PROCESS=CREA_IMAGEN:::AI_IMG_ID:'' || l_id || ''"'';',
'    l_html :=  REPLACE(l_html, ''src="aih" alt="aih##'' || l_file_name || ''"'', ''src="'' || l_url);',
'  ',
'     END LOOP;',
'',
'  RETURN l_html;',
'END ;'))
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_tag_attributes=>'style="border: none;"'
,p_field_template=>wwv_flow_imp.id(185555734732929198)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_04=>'N'
,p_attribute_05=>'HTML'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(269893576436260117)
,p_name=>'P1026_ID_AYUDA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(269889324111260118)
,p_use_cache_before_default=>'NO'
,p_item_default=>'2'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(56530242928347992)
,p_name=>'Highlight Code'
,p_event_sequence=>10
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(56530786884347993)
,p_event_id=>wwv_flow_imp.id(56530242928347992)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'PLUGIN_APEX.CODE.HIGHLIGHTER'
,p_affected_elements_type=>'JQUERY_SELECTOR'
,p_affected_elements=>'pre'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(56531255859347994)
,p_event_id=>wwv_flow_imp.id(56530242928347992)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_name=>'CopyButton'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var snippets = document.getElementsByTagName(''pre'');  ',
'for (var i = 0; i < snippets.length; i++) {  ',
'    var code = snippets[i].getElementsByTagName(''code'')[0].innerText;  ',
'    snippets[i].className += " code_width";',
'    // Create copy button  ',
'    var currentBtn = document.createElement("button");  ',
'    currentBtn.className += "hljs-copy";  ',
'      ',
'    // Add Font Awesome icon to the button  ',
'    var iconCopy = document.createElement("i");  ',
'        iconCopy.className += "fa fa-copy";  ',
'        currentBtn.appendChild(iconCopy);  ',
'      ',
'     // Add event listener to each button  ',
'     (function(code) {  ',
'        currentBtn.addEventListener("click", function(event) {  ',
'            event.preventDefault();  ',
'              ',
'            // Change button text to copied message and add checkmark icon  ',
'            this.innerHTML="<i class=''fa fa-check''></i>";  ',
'              ',
'            navigator.clipboard.writeText(code).then(() => {                ',
'              setTimeout(() => {  ',
'                // Change back to original text and add copy icon after delay   ',
'                this.innerHTML="<i class=''fa fa-copy''></i>";  ',
'              }, 5000);  ',
'            }, () => {   ',
'              console.error(''Failed to copy text.'');  ',
'            });  ',
'          });  ',
'            ',
'         // Append copy button before first child of pre tag  ',
'         var firstChildNode = snippets[i].getElementsByTagName(''code'')[0].childNodes[0];  ',
'         snippets[i].getElementsByTagName(''code'')[0].insertBefore(currentBtn, firstChildNode);  ',
'      })(code);  ',
'  ',
'}  ',
'',
'var figcaptions = document.getElementsByTagName(''figcaption'');',
'for (var i = 0; i < figcaptions.length; i++) {',
'    figcaptions[i].remove();',
'}',
'',
'// Get the element with the class "display_only apex-item-display-only"',
'var element = document.querySelector(''.display_only.apex-item-display-only'');',
'',
'// Get the first h2 tag inside the element',
'var h2 = element.querySelector(''h2:first-of-type'');',
'',
'// Get the text content of the h2 tag',
'var titulo = h2.textContent;',
'h2.remove();',
'$(''#titulo .t-Region-title'').text(titulo);',
'// Log the text content to the console',
'//console.log(text);'))
);
wwv_flow_imp.component_end;
end;
/
